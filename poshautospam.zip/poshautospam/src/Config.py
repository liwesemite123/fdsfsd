sellers_list = []

categories_list = [
    '/category/Women',
    '/category/Men',
    '/category/Kids',
    '/category/Home',
    '/category/Pets',
    '/category/Electronics'
]